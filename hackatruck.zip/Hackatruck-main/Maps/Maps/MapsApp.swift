//
//  MapsApp.swift
//  Maps
//
//  Created by Student16 on 06/09/23.
//

import SwiftUI

@main
struct MapsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
