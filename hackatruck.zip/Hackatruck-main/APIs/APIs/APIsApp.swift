
import SwiftUI

@main
struct APIsApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
