# Hackatruck
Repositório destinado aos projetos efetuados durante o Curso de Praticas de Cloud Services usando Swift com ênfase em Serviços Cognitivos
