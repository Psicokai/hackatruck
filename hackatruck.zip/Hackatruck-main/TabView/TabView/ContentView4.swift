//
//  ContentView4.swift
//  TabView
//
//  Created by Student16 on 04/09/23.
//

import SwiftUI

struct ContentView4: View {
    var body: some View {
        Text("jashdjasdhjakhjk")
    }
}

struct ContentView4_Previews: PreviewProvider {
    static var previews: some View {
        ContentView4()
    }
}
