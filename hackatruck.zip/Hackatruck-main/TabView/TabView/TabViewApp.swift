//
//  TabViewApp.swift
//  TabView
//
//  Created by Student16 on 04/09/23.
//

import SwiftUI

@main
struct TabViewApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
